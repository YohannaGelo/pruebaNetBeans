
package gestionAlumnos;

/**
 *
 * @author Yohanna Gelo
 */
public abstract class People {

    //ATRIBUTOS
    protected String name, surname, dni, direction, province, population;
    protected int cp;

    //CONSTRUCTORES
    public People(String name, String surname, String dni, String direction, String province, String population, int cp) {
        this.name = name;
        this.surname = surname;
        this.dni = dni;
        this.direction = direction;
        this.province = province;
        this.population = population;
        this.cp = cp;
    }

    public People() {
    }

    //CREAR ToSTRING Y GETTERS / SETTERS (si es necesario)
    @Override
    public String toString() {
        return "Nombre empleado\t: " + name + "\nApellidos\t: " + surname + "\nDNI\t\t: " + dni + "\nDirecci�n\t: " + direction
                + "\nProvincia\t: " + province + "\nC�digo Postal\t: " + cp + " (" + population + ")";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getPopulation() {
        return population;
    }

    public void setPopulation(String population) {
        this.population = population;
    }

    public int getCp() {
        return cp;
    }

    public void setCp(int cp) {
        this.cp = cp;
    }
    
    

}
